package com.example.navigator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
