
import 'package:flutter/material.dart';

import 'package:navigator/routes/screenmanager.dart';


class About extends StatelessWidget {
  const About({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var scaffold = Scaffold(  
      appBar: AppBar(  
        title: Text('About'),
      ),
      body:Text('about'),
      drawer: make_drawer(context),
    );
    return scaffold;
  }
}