
import 'package:flutter/material.dart';


import 'package:navigator/routes/screenmanager.dart';

class Settings extends StatelessWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var scaffold = Scaffold(  
      appBar: AppBar(  
        title: Text('Settings'),
      ),
      body:Text('settings'),
      drawer: make_drawer(context),
    );



    return scaffold;
  }
}