import 'package:flutter/material.dart';
import 'package:navigator/routes/screenmanager.dart';



class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    var scaffold = Scaffold(  
      appBar: AppBar(  
        title: Text('Homl'),
      ),
      body:Column(
        children: [
          screen_container(context),
          screen_container(context),
          screen_container(context),

              ]),
      drawer: make_drawer(context),
      bottomNavigationBar: bottom_navBar(context),
      floatingActionButton: FloatingActionButton(  
        child: Icon(Icons.share),
        onPressed: (){},
      ),
    );



    return scaffold;
  }
}