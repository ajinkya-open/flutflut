

import 'package:flutter/material.dart';

/////////// screens
import 'package:navigator/screens/home.dart';
import 'package:navigator/screens/about.dart';
import 'package:navigator/screens/settings.dart';

var routes_app = { 
  '/':(context) => Home(),
  '/about':(context) => About(),
  '/settings':(context) => Settings(),
};



Drawer make_drawer(ctx){
  return  Drawer(
  // Add a ListView to the drawer. This ensures the user can scroll
  // through the options in the drawer if there isn't enough vertical
  // space to fit everything.
  child: ListView(
    // Important: Remove any padding from the ListView.
    padding: EdgeInsets.zero,
    children: [
      const DrawerHeader(
        decoration: BoxDecoration(
          color: Colors.blue,
        ),
        child: Text('Drawer Header'),
      ),
      ListTile(
        title: const Text('Home'),
        onTap: () {
          Navigator.pushNamed(ctx, '/');
          // Update the state of the app.
          // ...
        },
      ),
      ListTile(
        title: const Text('About'),
        onTap: () {
          Navigator.pushNamed(ctx, '/about');
          // Update the state of the app.
          // ...
        },
      ),
      ListTile(
        title: const Text('Settings'),
        onTap: () {
          Navigator.pushNamed(ctx, '/settings');
          // Update the state of the app.
          // ...
        },
      ),
    ],
  ),
);
}



BottomNavigationBar bottom_navBar(ctx){ 
  return BottomNavigationBar(  
type: BottomNavigationBarType.fixed,
    items: <BottomNavigationBarItem>[  
      BottomNavigationBarItem(icon: Icon(Icons.home),label: 'Home'),
      BottomNavigationBarItem(icon: Icon(Icons.rule),label: 'Rules'),
      BottomNavigationBarItem(icon: Icon(Icons.list),label: 'Logs'),
      BottomNavigationBarItem(icon: Icon(Icons.list),label: 'Logs'),
    ],
  );
}



Card roomCard(ctx){  
  return Card(  
    elevation: 10,
    margin: EdgeInsets.all(12),
    shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ), 
    color: Colors.green,
    child:Padding(
      padding: const EdgeInsets.all(15.0),
      child: Column(  
        children: [  
          Icon(Icons.home,size: 20,),
          Text('Room'),
          Text('Room'),
        ],
      ),
    )
  );
}




Container screen_container(context){  
return Container(
          
          margin: EdgeInsets.all(10),
          height: MediaQuery.of(context).size.height/5,
          color: Colors.grey,
child:SingleChildScrollView(
  scrollDirection: Axis.horizontal,
  child: Row( 
            children:[ 
              roomCard(context),
              roomCard(context),
              roomCard(context),
              roomCard(context),
              roomCard(context),
              roomCard(context),
              roomCard(context),
              roomCard(context),
              roomCard(context),
              roomCard(context),
              roomCard(context),
            ]),
        ));



}