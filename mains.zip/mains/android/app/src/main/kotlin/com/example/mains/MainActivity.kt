package com.example.mains

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
